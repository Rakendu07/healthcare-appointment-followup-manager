-- Optional demo seed helper.
-- Password hashes below are for the password: Password123!
-- For real deployments, create users through /api/auth/register.

-- You can create users through the API instead.
-- This file intentionally does not insert real-looking patient information.
