import "dotenv/config";

export const env = {
  port: Number(process.env.PORT || 5000),
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  frontendUrl: process.env.FRONTEND_URL || "http://localhost:5173",
  llmApiKey: process.env.LLM_API_KEY,
  llmModel: process.env.LLM_MODEL || "gpt-4o-mini",
  llmBaseUrl: process.env.LLM_BASE_URL || undefined,
  smtp: {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from: process.env.MAIL_FROM || "Clinic <no-reply@example.com>"
  },
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    redirectUri: process.env.GOOGLE_REDIRECT_URI
  },
  slotHoldMinutes: Number(process.env.SLOT_HOLD_MINUTES || 5),
  reminderMinutesBefore: Number(process.env.REMINDER_MINUTES_BEFORE || 60)
};

if (!env.databaseUrl) console.warn("DATABASE_URL is not set.");
if (!env.jwtSecret) console.warn("JWT_SECRET is not set.");
