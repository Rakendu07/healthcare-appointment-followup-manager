import cron from "node-cron";
import { query } from "../config/db.js";
import { processNotificationQueue } from "../services/notificationService.js";
import { sendEmail } from "../services/emailService.js";

export function startWorkers() {
  // Every minute: clean expired holds.
  cron.schedule("* * * * *", async () => {
    try {
      await query("DELETE FROM slot_holds WHERE expires_at <= NOW()");
    } catch (e) {
      console.error("Hold cleanup:", e.message);
    }
  });

  // Every minute: process email outbox.
  cron.schedule("* * * * *", async () => {
    try {
      await processNotificationQueue();
    } catch (e) {
      console.error("Notification worker:", e.message);
    }
  });

  // Every five minutes: upcoming appointment reminders.
  cron.schedule("*/5 * * * *", async () => {
    try {
      const result = await query(
        `SELECT a.*, p.name patient_name, p.email patient_email,
                d.name doctor_name, d.email doctor_email
         FROM appointments a
         JOIN users p ON p.id=a.patient_id
         JOIN users d ON d.id=a.doctor_id
         WHERE a.status='CONFIRMED'
           AND a.reminder_sent_at IS NULL
           AND a.appointment_start BETWEEN NOW() + INTERVAL '55 minutes'
                                       AND NOW() + INTERVAL '65 minutes'`
      );

      for (const a of result.rows) {
        const text = `Reminder: your clinic appointment is scheduled for ${new Date(a.appointment_start).toLocaleString()}.`;
        await sendEmail({ to: a.patient_email, subject: "Appointment reminder", text });
        await sendEmail({ to: a.doctor_email, subject: "Appointment reminder", text });
        await query("UPDATE appointments SET reminder_sent_at=NOW() WHERE id=$1", [a.id]);
      }
    } catch (e) {
      console.error("Appointment reminder worker:", e.message);
    }
  });

  // Every five minutes: medication reminders.
  cron.schedule("*/5 * * * *", async () => {
    try {
      const result = await query(
        `SELECT mr.*, u.email, u.name
         FROM medication_reminders mr
         JOIN users u ON u.id=mr.patient_id
         WHERE mr.active=true AND mr.next_reminder_at IS NOT NULL
           AND mr.next_reminder_at <= NOW()
         LIMIT 100`
      );

      for (const r of result.rows) {
        await sendEmail({
          to: r.email,
          subject: `Medication reminder: ${r.medicine_name}`,
          text: `Medication reminder for ${r.name}: ${r.medicine_name}${r.dosage ? ` (${r.dosage})` : ""}. Frequency: ${r.frequency}.`
        });

        // Simple next reminder policy. Production systems should parse schedules
        // into explicit times rather than interpreting arbitrary text.
        await query(
          `UPDATE medication_reminders
           SET next_reminder_at = NOW() + INTERVAL '6 hours'
           WHERE id=$1`,
          [r.id]
        );
      }
    } catch (e) {
      console.error("Medication worker:", e.message);
    }
  });

  console.log("Background workers started.");
}
