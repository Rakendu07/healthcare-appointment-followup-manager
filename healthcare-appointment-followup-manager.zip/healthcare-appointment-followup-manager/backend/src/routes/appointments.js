import express from "express";
import { z } from "zod";
import { pool, query } from "../config/db.js";
import { auth, roles } from "../middleware/auth.js";
import { env } from "../config/env.js";
import { generatePreVisitSummary, generatePostVisitSummary } from "../services/llmService.js";
import { enqueueNotification } from "../services/notificationService.js";
import {
  createCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent
} from "../services/calendarService.js";

const router = express.Router();

router.get("/", auth, async (req, res, next) => {
  try {
    let sql = `
      SELECT a.*, p.name patient_name,p.email patient_email,
             d.name doctor_name,d.email doctor_email,
             dp.specialization
      FROM appointments a
      JOIN users p ON p.id=a.patient_id
      JOIN users d ON d.id=a.doctor_id
      JOIN doctor_profiles dp ON dp.id=d.id
    `;
    const params = [];

    if (req.user.role === "patient") {
      params.push(req.user.id);
      sql += ` WHERE a.patient_id=$1`;
    } else if (req.user.role === "doctor") {
      params.push(req.user.id);
      sql += ` WHERE a.doctor_id=$1`;
    }

    sql += " ORDER BY a.appointment_start DESC";

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (e) {
    next(e);
  }
});

router.post("/hold", auth, roles("patient"), async (req, res, next) => {
  try {
    const b = z.object({
      doctorId: z.string().uuid(),
      appointmentStart: z.string(),
      appointmentEnd: z.string()
    }).parse(req.body);

    const result = await query(
      `INSERT INTO slot_holds
       (doctor_id,patient_id,appointment_start,appointment_end,expires_at)
       VALUES($1,$2,$3,$4,NOW()+($5 || ' minutes')::interval)
       ON CONFLICT(doctor_id,appointment_start)
       DO UPDATE SET
         patient_id=EXCLUDED.patient_id,
         appointment_end=EXCLUDED.appointment_end,
         expires_at=EXCLUDED.expires_at
       WHERE slot_holds.expires_at <= NOW()
       RETURNING *`,
      [b.doctorId, req.user.id, b.appointmentStart, b.appointmentEnd, env.slotHoldMinutes]
    );

    if (!result.rowCount) {
      return res.status(409).json({ message: "Slot is currently held or booked" });
    }

    res.status(201).json(result.rows[0]);
  } catch (e) {
    next(e);
  }
});

router.post("/", auth, roles("patient"), async (req, res, next) => {
  const client = await pool.connect();

  try {
    const b = z.object({
      doctorId: z.string().uuid(),
      appointmentStart: z.string(),
      appointmentEnd: z.string(),
      symptoms: z.string().min(3)
    }).parse(req.body);

    await client.query("BEGIN");

    // Serialize booking decisions for a doctor.
    await client.query("SELECT id FROM users WHERE id=$1 AND role='doctor' FOR UPDATE", [b.doctorId]);

    const leave = await client.query(
      `SELECT 1 FROM doctor_leaves
       WHERE doctor_id=$1 AND leave_start < $3 AND leave_end > $2
       LIMIT 1`,
      [b.doctorId, b.appointmentStart, b.appointmentEnd]
    );

    if (leave.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ message: "Doctor is on leave for this slot" });
    }

    const hold = await client.query(
      `SELECT * FROM slot_holds
       WHERE doctor_id=$1 AND appointment_start=$2
         AND expires_at > NOW()
       FOR UPDATE`,
      [b.doctorId, b.appointmentStart]
    );

    if (hold.rowCount && hold.rows[0].patient_id !== req.user.id) {
      await client.query("ROLLBACK");
      return res.status(409).json({ message: "Slot is held by another patient" });
    }

    const appointment = await client.query(
      `INSERT INTO appointments
       (doctor_id,patient_id,appointment_start,appointment_end,symptoms)
       VALUES($1,$2,$3,$4,$5)
       RETURNING *`,
      [b.doctorId, req.user.id, b.appointmentStart, b.appointmentEnd, b.symptoms]
    );

    await client.query(
      `DELETE FROM slot_holds WHERE doctor_id=$1 AND appointment_start=$2`,
      [b.doctorId, b.appointmentStart]
    );

    await client.query("COMMIT");

    const a = appointment.rows[0];
    const summary = await generatePreVisitSummary(a.symptoms);

    await query(
      `UPDATE appointments
       SET previsit_summary=$2, previsit_ai_status=$3
       WHERE id=$1`,
      [a.id, JSON.stringify(summary.data), summary.status]
    );

    const people = await query(
      `SELECT p.id patient_id,p.email patient_email,p.name patient_name,
              d.id doctor_id,d.email doctor_email,d.name doctor_name
       FROM appointments a
       JOIN users p ON p.id=a.patient_id
       JOIN users d ON d.id=a.doctor_id
       WHERE a.id=$1`,
      [a.id]
    );

    const x = people.rows[0];

    await enqueueNotification({
      appointmentId: a.id,
      recipientUserId: x.patient_id,
      type: "BOOKING_CONFIRMATION",
      subject: "Appointment confirmed",
      body: `Your appointment with Dr. ${x.doctor_name} is confirmed for ${new Date(a.appointment_start).toLocaleString()}.`
    });

    await enqueueNotification({
      appointmentId: a.id,
      recipientUserId: x.doctor_id,
      type: "BOOKING_CONFIRMATION",
      subject: "New appointment booked",
      body: `A new appointment with ${x.patient_name} is confirmed for ${new Date(a.appointment_start).toLocaleString()}.`
    });

    // Calendar failures are deliberately non-blocking.
    const patientEvent = await createCalendarEvent(x.patient_id, {
      ...a,
      doctor_name: x.doctor_name
    });
    const doctorEvent = await createCalendarEvent(x.doctor_id, {
      ...a,
      patient_name: x.patient_name
    });

    await query(
      `UPDATE appointments
       SET google_event_patient_id=$2,google_event_doctor_id=$3
       WHERE id=$1`,
      [a.id, patientEvent, doctorEvent]
    );

    res.status(201).json({
      ...a,
      previsit_summary: summary.data,
      previsit_ai_status: summary.status
    });
  } catch (e) {
    await client.query("ROLLBACK");

    if (e.code === "23505") {
      return res.status(409).json({ message: "Slot was booked by another patient" });
    }

    next(e);
  } finally {
    client.release();
  }
});

router.post("/:id/previsit-summary", auth, async (req, res, next) => {
  try {
    const result = await query(
      "SELECT * FROM appointments WHERE id=$1 AND (patient_id=$2 OR doctor_id=$2)",
      [req.params.id, req.user.id]
    );
    if (!result.rowCount) return res.status(404).json({ message: "Appointment not found" });

    const summary = await generatePreVisitSummary(result.rows[0].symptoms);
    await query(
      "UPDATE appointments SET previsit_summary=$2,previsit_ai_status=$3 WHERE id=$1",
      [req.params.id, JSON.stringify(summary.data), summary.status]
    );

    res.json(summary);
  } catch (e) {
    next(e);
  }
});

router.post("/:id/visit", auth, roles("doctor"), async (req, res, next) => {
  try {
    const b = z.object({
      notes: z.string().min(3),
      prescription: z.array(z.object({
        medicineName: z.string(),
        dosage: z.string().optional(),
        frequency: z.string()
      })).default([]),
      followUp: z.string().optional()
    }).parse(req.body);

    const found = await query(
      "SELECT * FROM appointments WHERE id=$1 AND doctor_id=$2",
      [req.params.id, req.user.id]
    );
    if (!found.rowCount) return res.status(404).json({ message: "Appointment not found" });

    const summary = await generatePostVisitSummary(
      b.notes,
      b.prescription,
      b.followUp
    );

    await query(
      `UPDATE appointments
       SET status='COMPLETED',
           doctor_notes=$2,
           prescription=$3,
           postvisit_summary=$4,
           postvisit_ai_status=$5
       WHERE id=$1`,
      [
        req.params.id,
        b.notes,
        JSON.stringify(b.prescription),
        summary.text,
        summary.status
      ]
    );

    for (const medicine of b.prescription) {
      await query(
        `INSERT INTO medication_reminders
         (appointment_id,patient_id,medicine_name,dosage,frequency,next_reminder_at)
         SELECT $1,patient_id,$2,$3,$4,NOW()
         FROM appointments WHERE id=$1`,
        [req.params.id, medicine.medicineName, medicine.dosage || null, medicine.frequency]
      );
    }

    const appointment = found.rows[0];
    await enqueueNotification({
      appointmentId: req.params.id,
      recipientUserId: appointment.patient_id,
      type: "POST_VISIT_SUMMARY",
      subject: "Your visit summary",
      body: summary.text
    });

    res.json({ summary, prescription: b.prescription });
  } catch (e) {
    next(e);
  }
});

router.patch("/:id/reschedule", auth, roles("patient", "admin", "doctor"), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = z.object({
      appointmentStart: z.string(),
      appointmentEnd: z.string()
    }).parse(req.body);

    await client.query("BEGIN");

    const current = await client.query(
      "SELECT * FROM appointments WHERE id=$1 FOR UPDATE",
      [req.params.id]
    );
    if (!current.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Appointment not found" });
    }

    const a = current.rows[0];

    const conflict = await client.query(
      `SELECT 1 FROM appointments
       WHERE doctor_id=$1 AND appointment_start=$2
         AND id<>$3 AND status IN ('CONFIRMED','HELD')
       LIMIT 1`,
      [a.doctor_id, b.appointmentStart, a.id]
    );

    if (conflict.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ message: "New slot is already booked" });
    }

    const updated = await client.query(
      `UPDATE appointments
       SET appointment_start=$2,appointment_end=$3,status='CONFIRMED'
       WHERE id=$1 RETURNING *`,
      [a.id, b.appointmentStart, b.appointmentEnd]
    );

    await client.query("COMMIT");

    await updateCalendarEvent(a.patient_id, a.google_event_patient_id, updated.rows[0]);
    await updateCalendarEvent(a.doctor_id, a.google_event_doctor_id, updated.rows[0]);

    await enqueueNotification({
      appointmentId: a.id,
      recipientUserId: a.patient_id,
      type: "RESCHEDULE",
      subject: "Appointment rescheduled",
      body: `Your appointment has been rescheduled to ${new Date(b.appointmentStart).toLocaleString()}.`
    });

    await enqueueNotification({
      appointmentId: a.id,
      recipientUserId: a.doctor_id,
      type: "RESCHEDULE",
      subject: "Appointment rescheduled",
      body: `Appointment ${a.id} has been rescheduled to ${new Date(b.appointmentStart).toLocaleString()}.`
    });

    res.json(updated.rows[0]);
  } catch (e) {
    await client.query("ROLLBACK");
    if (e.code === "23505") return res.status(409).json({ message: "Slot conflict" });
    next(e);
  } finally {
    client.release();
  }
});

router.post("/:id/cancel", auth, async (req, res, next) => {
  try {
    const found = await query(
      "SELECT * FROM appointments WHERE id=$1 AND (patient_id=$2 OR doctor_id=$2 OR $3='admin')",
      [req.params.id, req.user.id, req.user.role]
    );

    if (!found.rowCount) return res.status(404).json({ message: "Appointment not found" });

    const a = found.rows[0];

    await query(
      "UPDATE appointments SET status='CANCELLED' WHERE id=$1",
      [a.id]
    );

    await deleteCalendarEvent(a.patient_id, a.google_event_patient_id);
    await deleteCalendarEvent(a.doctor_id, a.google_event_doctor_id);

    const people = await query(
      `SELECT id FROM users WHERE id IN ($1,$2)`,
      [a.patient_id, a.doctor_id]
    );

    for (const person of people.rows) {
      await enqueueNotification({
        appointmentId: a.id,
        recipientUserId: person.id,
        type: "CANCELLATION",
        subject: "Appointment cancelled",
        body: `Appointment ${a.id} has been cancelled.`
      });
    }

    res.json({ message: "Appointment cancelled" });
  } catch (e) {
    next(e);
  }
});

export default router;
