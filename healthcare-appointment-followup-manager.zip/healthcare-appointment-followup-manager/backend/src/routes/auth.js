import express from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { query } from "../config/db.js";
import { signUser } from "../utils/jwt.js";

const router = express.Router();

const registerSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["patient", "doctor", "admin"]).default("patient")
});

router.post("/register", async (req, res, next) => {
  try {
    const data = registerSchema.parse(req.body);
    const exists = await query("SELECT id FROM users WHERE email=$1", [data.email.toLowerCase()]);
    if (exists.rowCount) return res.status(409).json({ message: "Email already registered" });

    const hash = await bcrypt.hash(data.password, 12);
    const result = await query(
      `INSERT INTO users(name,email,password_hash,role)
       VALUES($1,$2,$3,$4)
       RETURNING id,name,email,role`,
      [data.name, data.email.toLowerCase(), hash, data.role]
    );

    const user = result.rows[0];

    if (user.role === "doctor") {
      await query(
        `INSERT INTO doctor_profiles(id,specialization)
         VALUES($1,'General Medicine')`,
        [user.id]
      );
    }

    res.status(201).json({ user, token: signUser(user) });
  } catch (e) {
    next(e);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").toLowerCase();
    const password = String(req.body.password || "");

    const result = await query("SELECT * FROM users WHERE email=$1", [email]);
    const user = result.rows[0];

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      token: signUser(user)
    });
  } catch (e) {
    next(e);
  }
});

export default router;
