import express from "express";
import { auth } from "../middleware/auth.js";
import { getCalendarAuthUrl, getOAuthClient, saveGoogleTokens } from "../services/calendarService.js";

const router = express.Router();

router.get("/oauth/start", auth, async (req, res) => {
  res.json({ url: getCalendarAuthUrl(req.user.id) });
});

router.get("/oauth/callback", async (req, res) => {
  try {
    const state = req.query.state;
    const code = req.query.code;
    if (!state || !code) return res.status(400).send("Missing OAuth state/code");

    const oauth = getOAuthClient();
    const { tokens } = await oauth.getToken(code);
    await saveGoogleTokens(state, tokens);

    res.redirect(`${process.env.FRONTEND_URL || "http://localhost:5173"}/calendar-connected`);
  } catch (e) {
    console.error(e);
    res.status(500).send("Google Calendar connection failed");
  }
});

export default router;
