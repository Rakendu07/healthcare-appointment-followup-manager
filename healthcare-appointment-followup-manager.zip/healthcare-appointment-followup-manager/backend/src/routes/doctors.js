import express from "express";
import { z } from "zod";
import { query } from "../config/db.js";
import { auth, roles } from "../middleware/auth.js";

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const specialization = req.query.specialization || "";
    const result = await query(
      `SELECT u.id,u.name,u.email,dp.specialization,dp.slot_duration_minutes,
              dp.working_start,dp.working_end,dp.timezone
       FROM users u
       JOIN doctor_profiles dp ON dp.id=u.id
       WHERE u.role='doctor'
         AND ($1='' OR dp.specialization ILIKE '%' || $1 || '%')
       ORDER BY u.name`,
      [specialization]
    );
    res.json(result.rows);
  } catch (e) {
    next(e);
  }
});

router.post("/", auth, roles("admin"), async (req, res, next) => {
  try {
    const body = z.object({
      name: z.string().min(2),
      email: z.string().email(),
      password: z.string().min(6),
      specialization: z.string().min(2),
      slotDurationMinutes: z.number().int().min(5).max(240).default(30),
      workingStart: z.string().default("09:00"),
      workingEnd: z.string().default("17:00")
    }).parse(req.body);

    const bcrypt = await import("bcryptjs");
    const hash = await bcrypt.default.hash(body.password, 12);

    const user = await query(
      `INSERT INTO users(name,email,password_hash,role)
       VALUES($1,$2,$3,'doctor')
       RETURNING id,name,email,role`,
      [body.name, body.email.toLowerCase(), hash]
    );

    await query(
      `INSERT INTO doctor_profiles
       (id,specialization,slot_duration_minutes,working_start,working_end)
       VALUES($1,$2,$3,$4,$5)`,
      [user.rows[0].id, body.specialization, body.slotDurationMinutes, body.workingStart, body.workingEnd]
    );

    res.status(201).json(user.rows[0]);
  } catch (e) {
    next(e);
  }
});

router.patch("/:id", auth, roles("admin"), async (req, res, next) => {
  try {
    const b = req.body;
    const result = await query(
      `UPDATE doctor_profiles
       SET specialization=COALESCE($2,specialization),
           slot_duration_minutes=COALESCE($3,slot_duration_minutes),
           working_start=COALESCE($4,working_start),
           working_end=COALESCE($5,working_end)
       WHERE id=$1
       RETURNING *`,
      [req.params.id, b.specialization, b.slotDurationMinutes, b.workingStart, b.workingEnd]
    );
    res.json(result.rows[0]);
  } catch (e) {
    next(e);
  }
});

router.post("/:id/leave", auth, roles("admin"), async (req, res, next) => {
  const client = await (await import("../config/db.js")).pool.connect();

  try {
    const b = z.object({
      leaveStart: z.string(),
      leaveEnd: z.string(),
      reason: z.string().optional()
    }).parse(req.body);

    await client.query("BEGIN");

    const leave = await client.query(
      `INSERT INTO doctor_leaves(doctor_id,leave_start,leave_end,reason)
       VALUES($1,$2,$3,$4) RETURNING *`,
      [req.params.id, b.leaveStart, b.leaveEnd, b.reason || null]
    );

    const affected = await client.query(
      `SELECT a.*, p.name patient_name, p.email patient_email,
              d.name doctor_name, d.email doctor_email
       FROM appointments a
       JOIN users p ON p.id=a.patient_id
       JOIN users d ON d.id=a.doctor_id
       WHERE a.doctor_id=$1
         AND a.status IN ('HELD','CONFIRMED')
         AND a.appointment_start < $3
         AND a.appointment_end > $2
       FOR UPDATE`,
      [req.params.id, b.leaveStart, b.leaveEnd]
    );

    for (const a of affected.rows) {
      await client.query(
        `UPDATE appointments SET status='CANCELLED' WHERE id=$1`,
        [a.id]
      );
      await client.query(
        `INSERT INTO notifications
         (appointment_id,recipient_user_id,type,subject,body)
         VALUES($1,$2,'LEAVE_CANCELLATION',$3,$4),
               ($1,$5,'LEAVE_CANCELLATION',$6,$7)`,
        [
          a.id,
          a.patient_id,
          "Appointment cancelled due to doctor leave",
          `Your appointment on ${new Date(a.appointment_start).toLocaleString()} has been cancelled because the doctor is unavailable.`,
          a.doctor_id,
          "Appointment cancelled due to leave",
          `Appointment ${a.id} was cancelled because you are on leave.`
        ]
      );
    }

    await client.query("COMMIT");
    res.status(201).json({
      leave: leave.rows[0],
      cancelledAppointments: affected.rowCount
    });
  } catch (e) {
    await client.query("ROLLBACK");
    next(e);
  } finally {
    client.release();
  }
});

router.delete("/:id/leave/:leaveId", auth, roles("admin"), async (req, res, next) => {
  try {
    await query("DELETE FROM doctor_leaves WHERE id=$1 AND doctor_id=$2", [
      req.params.leaveId, req.params.id
    ]);
    res.json({ message: "Leave removed" });
  } catch (e) {
    next(e);
  }
});

router.get("/:id/slots", async (req, res, next) => {
  try {
    const date = req.query.date;
    if (!date) return res.status(400).json({ message: "date is required" });

    const doctorResult = await query(
      "SELECT dp.*, u.name FROM doctor_profiles dp JOIN users u ON u.id=dp.id WHERE dp.id=$1",
      [req.params.id]
    );
    const doctor = doctorResult.rows[0];
    if (!doctor) return res.status(404).json({ message: "Doctor not found" });

    const day = new Date(`${date}T00:00:00`);
    const start = new Date(`${date}T${doctor.working_start}`);
    const end = new Date(`${date}T${doctor.working_end}`);

    const leave = await query(
      `SELECT 1 FROM doctor_leaves
       WHERE doctor_id=$1 AND leave_start < $3 AND leave_end > $2
       LIMIT 1`,
      [req.params.id, start.toISOString(), end.toISOString()]
    );

    if (leave.rowCount) return res.json([]);

    const bookings = await query(
      `SELECT appointment_start FROM appointments
       WHERE doctor_id=$1 AND status IN ('CONFIRMED','HELD')
         AND appointment_start::date=$2::date`,
      [req.params.id, date]
    );

    const holds = await query(
      `SELECT appointment_start FROM slot_holds
       WHERE doctor_id=$1 AND expires_at > NOW()
         AND appointment_start::date=$2::date`,
      [req.params.id, date]
    );

    const blocked = new Set([
      ...bookings.rows.map(x => new Date(x.appointment_start).getTime()),
      ...holds.rows.map(x => new Date(x.appointment_start).getTime())
    ]);

    const slots = [];
    const duration = doctor.slot_duration_minutes * 60000;

    for (let t = start.getTime(); t + duration <= end.getTime(); t += duration) {
      slots.push({
        start: new Date(t).toISOString(),
        end: new Date(t + duration).toISOString(),
        available: !blocked.has(t)
      });
    }

    res.json(slots);
  } catch (e) {
    next(e);
  }
});

export default router;
