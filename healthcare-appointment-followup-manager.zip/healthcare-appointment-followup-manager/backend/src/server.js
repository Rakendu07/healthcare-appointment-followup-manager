import { app } from "./app.js";
import { env } from "./config/env.js";
import { pool } from "./config/db.js";
import { startWorkers } from "./jobs/worker.js";

async function start() {
  await pool.query("SELECT 1");
  app.listen(env.port, () => {
    console.log(`Backend running on http://localhost:${env.port}`);
  });
  startWorkers();
}

start().catch((error) => {
  console.error("Startup failed:", error);
  process.exit(1);
});
