import { google } from "googleapis";
import { env } from "../config/env.js";
import { query } from "../config/db.js";

export function getOAuthClient() {
  return new google.auth.OAuth2(
    env.google.clientId,
    env.google.clientSecret,
    env.google.redirectUri
  );
}

export function getCalendarAuthUrl(state) {
  const oauth2Client = getOAuthClient();
  return oauth2Client.generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: ["https://www.googleapis.com/auth/calendar.events"],
    state
  });
}

export async function saveGoogleTokens(userId, tokens) {
  await query(
    `INSERT INTO google_tokens(user_id, access_token, refresh_token, scope, token_type, expiry_date)
     VALUES($1,$2,$3,$4,$5,$6)
     ON CONFLICT(user_id) DO UPDATE SET
       access_token=EXCLUDED.access_token,
       refresh_token=COALESCE(EXCLUDED.refresh_token, google_tokens.refresh_token),
       scope=EXCLUDED.scope,
       token_type=EXCLUDED.token_type,
       expiry_date=EXCLUDED.expiry_date,
       updated_at=NOW()`,
    [
      userId,
      tokens.access_token,
      tokens.refresh_token || null,
      tokens.scope || null,
      tokens.token_type || null,
      tokens.expiry_date || null
    ]
  );
}

async function getAuthorizedClient(userId) {
  const result = await query("SELECT * FROM google_tokens WHERE user_id=$1", [userId]);
  if (!result.rows[0]) return null;

  const oauth = getOAuthClient();
  oauth.setCredentials({
    access_token: result.rows[0].access_token,
    refresh_token: result.rows[0].refresh_token,
    expiry_date: Number(result.rows[0].expiry_date || 0)
  });

  return oauth;
}

export async function createCalendarEvent(userId, appointment) {
  try {
    const auth = await getAuthorizedClient(userId);
    if (!auth) return null;

    const calendar = google.calendar({ version: "v3", auth });
    const event = await calendar.events.insert({
      calendarId: "primary",
      requestBody: {
        summary: `Clinic appointment with ${appointment.doctor_name || appointment.patient_name}`,
        description: `Healthcare appointment. Appointment ID: ${appointment.id}`,
        start: { dateTime: new Date(appointment.appointment_start).toISOString() },
        end: { dateTime: new Date(appointment.appointment_end).toISOString() }
      }
    });

    return event.data.id;
  } catch (error) {
    console.error("Calendar create failure:", error.message);
    return null;
  }
}

export async function updateCalendarEvent(userId, eventId, appointment) {
  try {
    if (!eventId) return;
    const auth = await getAuthorizedClient(userId);
    if (!auth) return;

    const calendar = google.calendar({ version: "v3", auth });
    await calendar.events.patch({
      calendarId: "primary",
      eventId,
      requestBody: {
        start: { dateTime: new Date(appointment.appointment_start).toISOString() },
        end: { dateTime: new Date(appointment.appointment_end).toISOString() }
      }
    });
  } catch (error) {
    console.error("Calendar update failure:", error.message);
  }
}

export async function deleteCalendarEvent(userId, eventId) {
  try {
    if (!eventId) return;
    const auth = await getAuthorizedClient(userId);
    if (!auth) return;

    const calendar = google.calendar({ version: "v3", auth });
    await calendar.events.delete({ calendarId: "primary", eventId });
  } catch (error) {
    console.error("Calendar delete failure:", error.message);
  }
}
