import OpenAI from "openai";
import { env } from "../config/env.js";

const client = env.llmApiKey
  ? new OpenAI({ apiKey: env.llmApiKey, baseURL: env.llmBaseUrl })
  : null;

function cleanJson(text) {
  const match = text.match(/\{[\s\S]*\}/);
  return match ? JSON.parse(match[0]) : null;
}

export async function generatePreVisitSummary(symptoms) {
  if (!client) {
    return {
      status: "FAILED",
      data: {
        urgency: "Medium",
        chiefComplaint: "AI service is not configured.",
        suggestedQuestions: [
          "What symptoms are most concerning?",
          "When did the symptoms start?",
          "What information should I bring to the visit?"
        ]
      }
    };
  }

  try {
    const response = await client.chat.completions.create({
      model: env.llmModel,
      temperature: 0.1,
      messages: [
        {
          role: "system",
          content:
            "You are an administrative clinical summarization assistant. Do not diagnose. Return valid JSON only. Urgency is triage guidance for the clinician, not an emergency diagnosis."
        },
        {
          role: "user",
          content: `Analyse these symptoms and return:
{
  "urgency": "Low | Medium | High",
  "chiefComplaint": "short neutral summary",
  "suggestedQuestions": ["question 1", "question 2", "question 3"]
}
Symptoms: ${symptoms}`
        }
      ]
    });

    const parsed = cleanJson(response.choices?.[0]?.message?.content || "");
    if (!parsed) throw new Error("Invalid LLM JSON");

    return { status: "SUCCESS", data: parsed };
  } catch (error) {
    console.error("Pre-visit LLM failure:", error.message);
    return {
      status: "FAILED",
      data: {
        urgency: "Medium",
        chiefComplaint: "AI summary unavailable. Review the patient's original symptoms.",
        suggestedQuestions: [
          "What is the primary concern today?",
          "When did the symptoms begin and how have they changed?",
          "Are there relevant medicines, allergies, or previous conditions?"
        ]
      }
    };
  }
}

export async function generatePostVisitSummary(notes, prescription, followUp) {
  if (!client) {
    return {
      status: "FAILED",
      text: `Your visit summary is not AI-generated because the AI service is not configured.\n\nDoctor notes: ${notes}\nFollow-up: ${followUp || "As advised by your doctor."}`
    };
  }

  try {
    const response = await client.chat.completions.create({
      model: env.llmModel,
      temperature: 0.2,
      messages: [
        {
          role: "system",
          content:
            "Convert clinical notes into a patient-friendly summary. Do not add diagnoses, doses, or medical facts that are absent. Preserve the doctor's prescription exactly. Encourage the patient to follow the clinician's instructions."
        },
        {
          role: "user",
          content: `Convert these clinical notes into a patient-friendly summary with medication schedule and follow-up steps:
Clinical notes: ${notes}
Prescription: ${JSON.stringify(prescription || [])}
Follow-up: ${followUp || "Not specified"}`
        }
      ]
    });

    return {
      status: "SUCCESS",
      text: response.choices?.[0]?.message?.content || "Summary unavailable."
    };
  } catch (error) {
    console.error("Post-visit LLM failure:", error.message);
    return {
      status: "FAILED",
      text: `Your doctor has completed the visit. Please follow the prescription exactly as provided by your doctor.\n\nDoctor notes: ${notes}\nFollow-up: ${followUp || "As advised by your doctor."}`
    };
  }
}
