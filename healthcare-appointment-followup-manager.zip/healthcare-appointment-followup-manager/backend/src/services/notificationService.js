import { query } from "../config/db.js";
import { sendEmail } from "./emailService.js";

export async function enqueueNotification({ appointmentId, recipientUserId, type, subject, body }) {
  await query(
    `INSERT INTO notifications
      (appointment_id, recipient_user_id, type, subject, body)
     VALUES($1,$2,$3,$4,$5)`,
    [appointmentId || null, recipientUserId, type, subject, body]
  );
}

export async function processNotificationQueue() {
  const result = await query(
    `SELECT n.*, u.email
     FROM notifications n
     JOIN users u ON u.id=n.recipient_user_id
     WHERE n.status IN ('PENDING','FAILED')
       AND n.next_attempt_at <= NOW()
       AND n.attempts < 5
     ORDER BY n.created_at
     LIMIT 50`
  );

  for (const n of result.rows) {
    try {
      await query(
        `UPDATE notifications
         SET attempts=attempts+1, status='FAILED'
         WHERE id=$1`,
        [n.id]
      );

      await sendEmail({
        to: n.email,
        subject: n.subject,
        text: n.body
      });

      await query(
        `UPDATE notifications
         SET status='SENT', sent_at=NOW(), last_error=NULL
         WHERE id=$1`,
        [n.id]
      );
    } catch (error) {
      const delayMinutes = Math.pow(2, Math.min(n.attempts, 4));
      await query(
        `UPDATE notifications
         SET status='FAILED',
             last_error=$2,
             next_attempt_at=NOW() + ($3 || ' minutes')::interval
         WHERE id=$1`,
        [n.id, error.message, delayMinutes]
      );
    }
  }
}
