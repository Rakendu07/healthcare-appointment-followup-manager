# API Documentation

Base URL:

```text
http://localhost:5000/api
```

Authentication:

```http
Authorization: Bearer <JWT>
```

## Auth

### Register

`POST /auth/register`

```json
{
  "name": "Ammu",
  "email": "ammu@example.com",
  "password": "secret123",
  "role": "patient"
}
```

### Login

`POST /auth/login`

```json
{
  "email": "ammu@example.com",
  "password": "secret123"
}
```

---

## Doctors

### Search

`GET /doctors?specialization=cardiology`

### Create doctor

`POST /doctors`

Admin only.

```json
{
  "name": "Dr. Rao",
  "email": "rao@example.com",
  "password": "secret123",
  "specialization": "Cardiology",
  "slotDurationMinutes": 30,
  "workingStart": "09:00",
  "workingEnd": "17:00"
}
```

### Slots

`GET /doctors/:id/slots?date=2026-08-25`

---

## Appointments

### Hold a slot

`POST /appointments/hold`

Patient only.

```json
{
  "doctorId": "UUID",
  "appointmentStart": "2026-08-25T10:00:00.000Z",
  "appointmentEnd": "2026-08-25T10:30:00.000Z"
}
```

### Book

`POST /appointments`

```json
{
  "doctorId": "UUID",
  "appointmentStart": "2026-08-25T10:00:00.000Z",
  "appointmentEnd": "2026-08-25T10:30:00.000Z",
  "symptoms": "Persistent cough for four days and mild fever."
}
```

### List appointments

`GET /appointments`

The result is filtered automatically by role.

### Generate/retry pre-visit summary

`POST /appointments/:id/previsit-summary`

### Complete visit

`POST /appointments/:id/visit`

Doctor only.

```json
{
  "notes": "Patient evaluated. Continue hydration and rest.",
  "prescription": [
    {
      "medicineName": "Example medicine",
      "dosage": "As prescribed",
      "frequency": "twice daily"
    }
  ],
  "followUp": "Review after 7 days."
}
```

### Reschedule

`PATCH /appointments/:id/reschedule`

```json
{
  "appointmentStart": "2026-08-26T10:00:00.000Z",
  "appointmentEnd": "2026-08-26T10:30:00.000Z"
}
```

### Cancel

`POST /appointments/:id/cancel`

---

## Leave

Admin:

`POST /doctors/:id/leave`

```json
{
  "leaveStart": "2026-08-25T00:00:00.000Z",
  "leaveEnd": "2026-08-26T00:00:00.000Z",
  "reason": "Personal leave"
}
```

Existing overlapping appointments are cancelled and notification records are queued.

---

## Google Calendar

### Start OAuth

`GET /calendar/oauth/start`

Returns:

```json
{
  "url": "https://accounts.google.com/..."
}
```

The browser is redirected to Google's OAuth page.

### OAuth callback

`GET /calendar/oauth/callback?code=...&state=...`

The callback stores tokens and redirects to the frontend.
