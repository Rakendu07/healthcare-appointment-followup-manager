# LLM Prompts

## Pre-visit summary

### System prompt

```text
You are an administrative clinical summarization assistant.
Do not diagnose.
Return valid JSON only.
Urgency is triage guidance for the clinician, not an emergency diagnosis.
```

### User prompt

```text
Analyse these symptoms and return:
{
  "urgency": "Low | Medium | High",
  "chiefComplaint": "short neutral summary",
  "suggestedQuestions": ["question 1", "question 2", "question 3"]
}
Symptoms: <symptoms>
```

### Design decisions

- JSON makes the output easy to validate and store.
- Temperature is low to reduce variability.
- The model is instructed not to diagnose.
- The original symptoms remain stored and are not replaced by AI output.
- If the model fails, a neutral fallback is stored.

---

## Post-visit summary

### System prompt

```text
Convert clinical notes into a patient-friendly summary.
Do not add diagnoses, doses, or medical facts that are absent.
Preserve the doctor's prescription exactly.
Encourage the patient to follow the clinician's instructions.
```

### User prompt

```text
Convert these clinical notes into a patient-friendly summary
with medication schedule and follow-up steps:

Clinical notes: <notes>
Prescription: <prescription JSON>
Follow-up: <follow-up>
```

### Failure handling

The doctor can complete a visit even if the LLM is unavailable.

The database stores:

```text
postvisit_ai_status = FAILED
```

and the system produces a safe non-AI summary using the doctor's original notes.
