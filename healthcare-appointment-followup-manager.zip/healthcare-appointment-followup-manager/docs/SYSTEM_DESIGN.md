# System Design — Healthcare Appointment & Follow-up Manager

## 1. Architecture

The system uses a React frontend, Express REST API, PostgreSQL database, background workers, an LLM provider, SMTP email, and Google Calendar OAuth.

```text
Patient / Doctor / Admin
          |
       React UI
          |
       REST API
          |
  ----------------------
  |         |          |
Postgres   LLM      Integrations
  |                   |-- SMTP
  |                   |-- Google Calendar
  |
Background Workers
  |-- expired holds
  |-- email retries
  |-- appointment reminders
  |-- medication reminders
```

## 2. Double-booking prevention

The strongest guarantee is enforced by PostgreSQL rather than only by frontend validation.

`appointments` contains:

```text
UNIQUE(doctor_id, appointment_start)
```

The booking endpoint also starts a database transaction and locks the doctor row using `SELECT ... FOR UPDATE`. It checks leave and active holds while the transaction is in progress, then inserts the appointment.

If two requests arrive at the same time, only one can successfully reserve the same doctor/start timestamp. The losing transaction receives a conflict response.

This is important because checking availability in the frontend alone has a race condition: two patients can both see a slot as free before either request reaches the database.

## 3. Slot hold mechanism

Before final confirmation, the patient can create a short-lived hold. `slot_holds` has a unique `(doctor_id, appointment_start)` constraint and an expiration timestamp.

The default hold is five minutes. A worker removes expired holds every minute.

An active hold blocks other patients. The patient who owns the hold can convert it into an appointment. This reduces the chance that a slot disappears while the patient is filling the symptom form.

## 4. Doctor leave conflict handling

Leave is represented by a start/end time range. When an admin creates leave, the API transaction finds all active appointments overlapping the range and locks them.

Affected appointments are changed to `CANCELLED`, notification records are inserted for patient and doctor, and calendar deletion is attempted.

Email/calendar failures do not roll back the leave decision because the appointment state is authoritative in the database.

## 5. Notification reliability

The notification table is an outbox-like queue. Booking, cancellation, rescheduling, and leave workflows create notification rows rather than relying on a single synchronous email request.

A worker processes pending/failed notifications. Each attempt is recorded. Failed messages use a simple exponential retry delay and stop after five attempts.

Therefore, an SMTP outage does not make appointment booking fail.

## 6. LLM reliability

LLM calls are isolated in a service layer. AI output is supplementary and is never required to create or complete an appointment.

The pre-visit summary stores structured JSON and an AI status. The post-visit summary stores text and an AI status.

If the provider is unavailable or returns malformed output, the application stores `FAILED` and returns a safe fallback. The doctor/patient still has access to the original clinical text.

## 7. Database design

Core tables:

- `users`: identity and role
- `doctor_profiles`: doctor-specific configuration
- `doctor_leaves`: unavailable time ranges
- `slot_holds`: temporary reservations
- `appointments`: booking and visit record
- `google_tokens`: OAuth credentials
- `notifications`: reliable notification queue
- `medication_reminders`: recurring reminder records

Indexes support doctor/time, patient/time, leave ranges, notification retries, and due medication reminders.

## 8. Calendar integration

Google Calendar uses OAuth 2.0. A user authorizes calendar access, and the application stores access/refresh tokens.

On appointment creation, events are attempted for both patient and doctor. Their event IDs are stored on the appointment.

Reschedule updates those event IDs. Cancellation deletes the events. Calendar failures are logged but do not invalidate the appointment transaction.

## 9. Security

JWT authentication and role middleware protect APIs. Passwords are hashed with bcrypt. Input validation uses Zod. Production deployments should enforce HTTPS, strict CORS, rate limiting, audit logs, encryption, secure secrets, backups, and applicable healthcare privacy requirements.

## 10. Scaling considerations

For a larger clinic, move background jobs to Redis/BullMQ or another durable queue, use a dedicated worker process, encrypt OAuth tokens at rest, use structured logging and distributed tracing, and replace the simple medication-frequency parser with explicit schedule data.
