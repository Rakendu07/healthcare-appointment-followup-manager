import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { api } from "../services/api";

export function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    try {
      const { data } = await api.post("/auth/login", form);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      navigate("/dashboard");
    } catch (e) {
      setError(e.response?.data?.message || "Login failed");
    }
  }

  return <AuthForm title="Welcome back" button="Login" form={form} setForm={setForm}
    error={error} submit={submit} showRole={false} />;
}

export function Register() {
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "patient" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    try {
      const { data } = await api.post("/auth/register", form);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      navigate("/dashboard");
    } catch (e) {
      setError(e.response?.data?.message || "Registration failed");
    }
  }

  return <AuthForm title="Create account" button="Register" form={form} setForm={setForm}
    error={error} submit={submit} showRole={true} />;
}

function AuthForm({ title, button, form, setForm, error, submit, showRole }) {
  return (
    <div className="card auth">
      <h2>{title}</h2>
      {showRole && (
        <label>Role
          <select value={form.role} onChange={e => setForm({...form, role:e.target.value})}>
            <option value="patient">Patient</option>
            <option value="doctor">Doctor</option>
            <option value="admin">Admin</option>
          </select>
        </label>
      )}
      {showRole && <label>Name<input required value={form.name} onChange={e => setForm({...form,name:e.target.value})}/></label>}
      <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form,email:e.target.value})}/></label>
      <label>Password<input type="password" required value={form.password} onChange={e => setForm({...form,password:e.target.value})}/></label>
      {error && <div className="error">{error}</div>}
      <button className="primary" onClick={submit}>{button}</button>
    </div>
  );
}
