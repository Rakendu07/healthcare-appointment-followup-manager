import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../services/api";

export default function BookAppointment() {
  const [specialization, setSpecialization] = useState("");
  const [doctors, setDoctors] = useState([]);
  const [doctorId, setDoctorId] = useState("");
  const [date, setDate] = useState("");
  const [slots, setSlots] = useState([]);
  const [symptoms, setSymptoms] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  async function search() {
    const { data } = await api.get("/doctors", { params: { specialization } });
    setDoctors(data);
  }

  async function loadSlots(id = doctorId, d = date) {
    if (!id || !d) return;
    const { data } = await api.get(`/doctors/${id}/slots`, { params: { date: d } });
    setSlots(data);
  }

  async function book(slot) {
    try {
      // Optional hold step before confirmation.
      await api.post("/appointments/hold", {
        doctorId,
        appointmentStart: slot.start,
        appointmentEnd: slot.end
      });

      const { data } = await api.post("/appointments", {
        doctorId,
        appointmentStart: slot.start,
        appointmentEnd: slot.end,
        symptoms
      });

      setMessage(`Booked successfully. AI status: ${data.previsit_ai_status}`);
      setTimeout(() => navigate("/dashboard"), 700);
    } catch (e) {
      setMessage(e.response?.data?.message || "Booking failed");
      loadSlots();
    }
  }

  useEffect(() => { search(); }, []);

  return (
    <div>
      <h1>Book an appointment</h1>
      <div className="card">
        <label>Specialization
          <input value={specialization} onChange={e => setSpecialization(e.target.value)} placeholder="Cardiology"/>
        </label>
        <button className="secondary" onClick={search}>Search doctors</button>

        <label>Doctor
          <select value={doctorId} onChange={e => {setDoctorId(e.target.value); setSlots([]);}}>
            <option value="">Select doctor</option>
            {doctors.map(d => <option key={d.id} value={d.id}>{d.name} — {d.specialization}</option>)}
          </select>
        </label>

        <label>Date
          <input type="date" value={date} onChange={e => {setDate(e.target.value); loadSlots(doctorId,e.target.value)}}/>
        </label>

        <label>Symptoms (required before confirmation)
          <textarea rows="5" value={symptoms} onChange={e => setSymptoms(e.target.value)}
            placeholder="Describe your symptoms, when they started, and anything relevant to the visit."/>
        </label>
      </div>

      <h2>Available slots</h2>
      <div className="slot-grid">
        {slots.filter(s => s.available).map(slot => (
          <button className="slot" key={slot.start} disabled={!symptoms.trim()} onClick={() => book(slot)}>
            {new Date(slot.start).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}
          </button>
        ))}
      </div>
      {message && <div className="notice">{message}</div>}
    </div>
  );
}
