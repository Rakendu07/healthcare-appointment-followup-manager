import { useState } from "react";
import { api } from "../services/api";

export default function Calendar() {
  const [message, setMessage] = useState("");

  async function connect() {
    try {
      const { data } = await api.get("/calendar/oauth/start");
      window.location.href = data.url;
    } catch {
      setMessage("Google Calendar configuration is unavailable.");
    }
  }

  return (
    <div className="card">
      <h1>Google Calendar</h1>
      <p>Authorize the application to create and update appointment events.</p>
      <button className="primary" onClick={connect}>Connect Google Calendar</button>
      {message && <p className="error">{message}</p>}
    </div>
  );
}
