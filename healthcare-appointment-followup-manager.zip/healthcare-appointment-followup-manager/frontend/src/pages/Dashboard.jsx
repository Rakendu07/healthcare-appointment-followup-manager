import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api";

export default function Dashboard() {
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    api.get("/appointments").then(r => setAppointments(r.data)).catch(console.error);
  }, []);

  return (
    <div>
      <div className="page-head">
        <div>
          <p className="eyebrow">{user?.role?.toUpperCase()}</p>
          <h1>Hello, {user?.name}</h1>
        </div>
        {user?.role === "patient" && <Link className="primary" to="/book">Book appointment</Link>}
      </div>

      {user?.role === "patient" && (
        <div className="card">
          <h3>Google Calendar</h3>
          <p>Connect your Google Calendar to create appointment events automatically.</p>
          <Link className="secondary" to="/calendar">Connect calendar</Link>
        </div>
      )}

      <h2>Appointments</h2>
      <div className="grid">
        {appointments.map(a => (
          <article className="card" key={a.id}>
            <span className={`badge ${a.status.toLowerCase()}`}>{a.status}</span>
            <h3>{user.role === "doctor" ? a.patient_name : `Dr. ${a.doctor_name}`}</h3>
            <p>{new Date(a.appointment_start).toLocaleString()}</p>
            <p>{a.specialization}</p>
            {a.previsit_summary && (
              <details>
                <summary>AI pre-visit summary</summary>
                <pre>{JSON.stringify(a.previsit_summary, null, 2)}</pre>
              </details>
            )}
            {a.postvisit_summary && (
              <details>
                <summary>Post-visit summary</summary>
                <p>{a.postvisit_summary}</p>
              </details>
            )}
          </article>
        ))}
      </div>
    </div>
  );
}
