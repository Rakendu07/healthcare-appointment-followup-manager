import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section className="hero">
      <div>
        <p className="eyebrow">Healthcare appointments, simplified</p>
        <h1>Book care. Prepare better. Follow up clearly.</h1>
        <p>
          Patients can share symptoms before a visit, doctors receive an AI-assisted
          summary, and patients receive a clear post-visit summary and medication reminders.
        </p>
        <div className="actions">
          <Link className="primary" to="/register">Get started</Link>
          <Link className="secondary" to="/login">Sign in</Link>
        </div>
      </div>
    </section>
  );
}
